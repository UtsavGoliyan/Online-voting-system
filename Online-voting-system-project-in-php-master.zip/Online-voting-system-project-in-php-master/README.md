# ONLINE-VOTING-SYSTEM-in-PHP-MYSQL



This system allows all registered users to vote for their favorite PROGRAMMING LANGUAGE.
In order to make a vote you have to register first and then login.

more projects visit - https://projectworlds.in

YouTube - https://youtu.be/mQiLqIhWXxM

